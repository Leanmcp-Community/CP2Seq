// The synthetic Pureland corpus generator.
//
//   square --random simple folds--> sequence --unfold--> crease pattern
//
// Bucket A BY CONSTRUCTION: the (CP, sequence) pair is built, not labelled, so there is
// nothing to annotate and nothing to trust (DATASET.md section 0).
//
// DIFFICULTY IS STRATIFIED, NOT SAMPLED AND HOPED FOR.
// Two axes, matching Learn2Fold's step count + non-local dependency (papers.md #4):
//
//   axis 1  STEPS -- the frozen main axis (experiment-spec-checklist.md B), controlled
//           directly at generation time. The tertiles below are 4-10 / 11-13 / 14-19.
//
//           /!\ These cut points were originally calibrated against an outside corpus of
//           human-folded sequences. That dependency is gone: the corpus is self-contained now,
//           so the range is ours to choose and the numbers below are simply the span the
//           generator covers, split in three. Change them here if the spread should differ --
//           there is no longer an external distribution they have to match.
//
//   axis 2  COUPLING -- creases created per fold, i.e. how many layers one fold cuts. Recorded
//           per step and summarised per sample, NOT yet used for quotas: its cut points are
//           "pending pilot" in the checklist. We control this sampler, so the spread is an open
//           empirical question -- `report.md` prints the distribution so the cut points can be
//           chosen from data rather than guessed. Pass --coupling-strata to turn it into quotas
//           once that number exists.
//
// WHAT COMES OUT. Every sample keeps both endpoints and the whole middle:
//   cp.fold          the crease pattern, planarised
//   seq.json         every fold: line, direction, the creases it made, its coupling
//   steps.fold       CP + the folded state after every step, one multi-frame FOLD file
//                    (--export-steps). Order is the file_frames array order; see planarize.mjs
//   meta.json        difficulty metrics, degeneracy flags, provenance
// Given the seed the whole sample rebuilds, so the corpus is reproducible without shipping it.
//
// THERE IS NO SOLVER HERE, AND NOTHING IS "VERIFIED" BY SEARCH.
// The sequence is not a claim that needs checking -- we folded it, and the pattern is what the
// folding left behind. An earlier version ran a search back over each sample and labelled the
// subset it could recover; that cost grew with depth, so it capped the corpus at the depth the
// search could reach and made every "verified" sample an easy one. The forward check that
// matters is verify-replay.mjs: replay the recorded sequence and confirm it reproduces the
// pattern beside it. O(folds), same cost at nineteen folds as at three.
import fs from "fs";
import path from "path";
import { resolvePath } from "./paths.mjs";
import { fileURLToPath } from "url";
import { foldRandom, polyArea, bbox } from "./fold-engine.mjs";
import { planarize, foldedState, sequenceFile } from "./planarize.mjs";
import { lineOf, lkey } from "./geom.mjs";

const HERE = path.dirname(fileURLToPath(import.meta.url));

// mulberry32: small, seeded, and far better distributed than the LCG the probe used
const rngFrom = (seed) => {
    let a = seed >>> 0;
    return () => {
        a = (a + 0x6D2B79F5) >>> 0;
        let t = Math.imul(a ^ (a >>> 15), 1 | a);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
};

// step tertiles -- see the header note
const DEFAULT_STRATA = [
    { name: "easy", min: 4,  max: 10 },
    { name: "mid",  min: 11, max: 13 },
    { name: "hard", min: 14, max: 19 },
];

/* ---------- isomorphism: a CP and its 8 square symmetries are the same sample ------------ */
const SYMS = [
    (p) => [p[0], p[1]],         (p) => [1 - p[0], p[1]],
    (p) => [p[0], 1 - p[1]],     (p) => [1 - p[0], 1 - p[1]],
    (p) => [p[1], p[0]],         (p) => [1 - p[1], p[0]],
    (p) => [p[1], 1 - p[0]],     (p) => [1 - p[1], 1 - p[0]],
];
function canonical(fold) {
    const r = (v) => Math.round(v * 1e6) / 1e6;
    let best = null;
    for (const S of SYMS) {
        const rows = fold.edges_vertices.map(([u, w], i) => {
            const A = S(fold.vertices_coords[u]), B = S(fold.vertices_coords[w]);
            const [p, q] = (A[0] < B[0] || (A[0] === B[0] && A[1] <= B[1])) ? [A, B] : [B, A];
            return `${r(p[0])},${r(p[1])},${r(q[0])},${r(q[1])},${fold.edges_assignment[i]}`;
        }).sort();
        const s = rows.join(";");
        if (best === null || s < best) best = s;
    }
    // a short digest is enough for dedup and keeps meta.json readable
    let h1 = 0x811c9dc5, h2 = 0x01000193;
    for (let i = 0; i < best.length; i++) {
        h1 = Math.imul(h1 ^ best.charCodeAt(i), 16777619) >>> 0;
        h2 = Math.imul(h2 + best.charCodeAt(i), 2246822519) >>> 0;
    }
    return h1.toString(16).padStart(8, "0") + h2.toString(16).padStart(8, "0");
}

/* ---------- difficulty + degeneracy ----------------------------------------------------- */
function measure(run, pl) {
    const created = run.seq.map(s => s.creases_created);
    const lines = new Set();
    for (const c of run.creases) { const l = lineOf(c.P, c.Q); if (l) lines.add(lkey(l)); }
    const angles = new Set(run.seq.map(s => s.angle_deg));
    const fin = bbox(run.layers);
    const mv = pl.stats.counts;

    const m = {
        steps: run.seq.length,
        crease_segments_raw: run.creases.length,
        crease_edges: (mv.M || 0) + (mv.V || 0),
        mountain: mv.M || 0, valley: mv.V || 0, border: mv.B || 0,
        distinct_crease_lines: lines.size,
        vertices: pl.stats.vertices,
        // --- axis 2: non-local coupling / layers bent at once ---
        coupling_max: Math.max(...created),
        coupling_mean: +(created.reduce((a, b) => a + b, 0) / created.length).toFixed(3),
        coupling_total: created.reduce((a, b) => a + b, 0),
        coupling_final_step: created[created.length - 1],
        layers_final: run.layers.length,
        distinct_angles: angles.size,
        bbox_area_final: +fin.area.toFixed(6),
        largest_face_final: +Math.max(...run.layers.map(l => polyArea(l.poly))).toFixed(6),
    };

    // Flags are RECORDED, not enforced. The checklist puts degeneracy cut points at
    // "pending pilot" and corpus-plan.md says explicitly: look at the first batch before
    // designing the filter. --reject turns any of these into a hard filter once that is done.
    m.flags = {
        // every fold on a handful of lines = "fold it in half over and over"
        repeated_halving: m.distinct_crease_lines < Math.ceil(m.steps * 0.75),
        // never cut more than one layer: the non-local coupling that makes this hard is absent
        no_coupling: m.coupling_max <= 1,
        // the paper collapsed to a sliver, so later folds are geometrically trivial
        collapsed: m.bbox_area_final < 0.05,
        // folds along a single direction family
        single_angle: m.distinct_angles <= 1,
    };
    m.degenerate = Object.values(m.flags).some(Boolean);
    return m;
}

/* ---------- one sample ------------------------------------------------------------------- */
export function build(seed, steps, opts) {
    const rand = rngFrom(seed);
    const run = foldRandom(steps, rand, {
        snapshots: opts.snapshots,
        couplingCap: opts.couplingCap, couplingFrac: opts.couplingFrac });
    if (!run.ok) return { reject: `stalled at step ${run.stalledAt}` };
    if (!run.creases.length) return { reject: "no creases" };
    if (!run.exactOk) return { reject: "placement lost exactness" };

    const segs = [
        { P: [0, 0], Q: [1, 0], assignment: "B" }, { P: [1, 0], Q: [1, 1], assignment: "B" },
        { P: [1, 1], Q: [0, 1], assignment: "B" }, { P: [0, 1], Q: [0, 0], assignment: "B" },
        ...run.creases.map(c => ({ P: c.P, Q: c.Q, assignment: c.a })),
    ];
    const pl = planarize(segs);
    if (pl.stats.assignment_conflicts) return { reject: "M/V conflict survived planarisation" };
    if (pl.stats.non_bmv_edges) return { reject: "non-BMV edge (F edges are out of scope)" };

    const metrics = measure(run, pl);
    if (opts.reject.some(f => metrics.flags[f])) return { reject: `degenerate: ${opts.reject.filter(f => metrics.flags[f]).join(",")}` };

    return { run, fold: pl.fold, plStats: pl.stats, metrics, hash: canonical(pl.fold) };
}

/* ---------- CLI ------------------------------------------------------------------------- */
const arg = (k, dflt) => {
    const i = process.argv.indexOf(`--${k}`);
    return i > 0 && process.argv[i + 1] ? process.argv[i + 1] : dflt;
};
const has = (k) => process.argv.includes(`--${k}`);

const N = Number(arg("n", 30));                       // samples PER STRATUM
const SEED0 = Number(arg("seed", 20260916));
const OUT = resolvePath(HERE, arg("out", null), "out/pilot");
const MAX_ATTEMPTS = Number(arg("max-attempts", 40)) * N;
const EXPORT_STEPS = has("export-steps");
const REJECT = (arg("reject", "") || "").split(",").filter(Boolean);
// both unset by default -- see the coupling-cap note in fold-engine.mjs
const COUPLING_CAP = arg("coupling-cap", null) ? Number(arg("coupling-cap")) : undefined;
const COUPLING_FRAC = arg("coupling-frac", null) ? Number(arg("coupling-frac")) : undefined;

const strata = arg("strata", null)
    ? JSON.parse(fs.readFileSync(arg("strata"), "utf8"))
    : DEFAULT_STRATA;

// basename, not endsWith: a sibling named test-generate.mjs would end with generate.mjs too,
// and importing it would then generate a corpus as a side effect. The guard exists so build()
// above can be imported -- callers need the all-layers sampler to put the two tiers'
// search cost on one axis, and a second copy of the sampler would not be the same corpus.
const IS_MAIN = process.argv[1] && path.basename(process.argv[1]) === "generate.mjs";
if (IS_MAIN) {
fs.rmSync(OUT, { recursive: true, force: true });
fs.mkdirSync(path.join(OUT, "samples"), { recursive: true });


const manifest = [], rejects = {}, seen = new Map();
let seed = SEED0;

console.log(`synthetic Pureland corpus -> ${path.relative(process.cwd(), OUT)}`);
console.log(`strata: ${strata.map(s => `${s.name}[${s.min}-${s.max}]n=${s.n ?? N}`).join("  ")}\n`);

for (const st of strata) {
    // A stratum may set its own quota. --n stays the default for any that does not, so the two
    // ways of asking are the same mechanism. This is one invocation rather than one per stratum
    // deliberately: `seen` is what rejects isomorphic duplicates, and splitting the run would
    // split that table, so duplicates ACROSS strata would stop being caught.
    const quota = st.n ?? N;
    let made = 0, attempts = 0;
    while (made < quota && attempts < MAX_ATTEMPTS) {
        attempts++;
        const s = seed++;
        const steps = st.min + Math.floor(rngFrom(s ^ 0x9e3779b9)() * (st.max - st.min + 1));
        // a stratum may carry its own cap, which is how the coupling axis becomes a CONTROLLED
        // variable rather than an observed one -- see strata-3x3.json
        const r = build(s, steps, { reject: REJECT, snapshots: EXPORT_STEPS,
                                    couplingCap: st.coupling_cap ?? COUPLING_CAP,
                                    couplingFrac: st.coupling_frac ?? COUPLING_FRAC });
        if (r.reject) { rejects[r.reject.split(":")[0]] = (rejects[r.reject.split(":")[0]] || 0) + 1; continue; }
        if (seen.has(r.hash)) { rejects["duplicate CP (isomorphic)"] = (rejects["duplicate CP (isomorphic)"] || 0) + 1; continue; }
        seen.set(r.hash, true);

        const id = `${st.name}-${String(made + 1).padStart(4, "0")}`;
        const dir = path.join(OUT, "samples", id);
        fs.mkdirSync(dir, { recursive: true });
        fs.writeFileSync(path.join(dir, "cp.fold"), JSON.stringify(r.fold));
        fs.writeFileSync(path.join(dir, "seq.json"), JSON.stringify({
            id, seed: s, steps: r.run.seq.length, folds: r.run.seq }, null, 1));

        if (EXPORT_STEPS)
            fs.writeFileSync(path.join(dir, "steps.fold"),
                             JSON.stringify(sequenceFile(r.fold, r.run.states, { id })));

        const meta = { id, stratum: st.name, seed: s, requested_steps: steps,
                       cp_hash: r.hash, metrics: r.metrics, planarize: r.plStats };
        fs.writeFileSync(path.join(dir, "meta.json"), JSON.stringify(meta, null, 1));
        manifest.push(meta);
        made++;
        process.stdout.write(`\r  ${st.name}: ${made}/${quota}   (${attempts} attempts)      `);
    }
    console.log(made < quota ? `\r  ${st.name}: ${made}/${quota}  <-- QUOTA NOT FILLED in ${attempts} attempts` 
                         : `\r  ${st.name}: ${made}/${quota}   (${attempts} attempts)      `);
}

fs.writeFileSync(path.join(OUT, "manifest.json"), JSON.stringify(
    { generated: new Date().toISOString(), seed0: SEED0, strata, n_per_stratum: N, n_by_stratum: Object.fromEntries(strata.map(s => [s.name, s.n ?? N])),
      reject_filters: REJECT, coupling_cap: COUPLING_CAP ?? null,
      coupling_frac: COUPLING_FRAC ?? null, samples: manifest }, null, 1));

/* ---------- the distribution report: this is what the cut points get chosen from -------- */
const q = (xs, p) => { const s = [...xs].sort((a, b) => a - b); return s[Math.min(s.length - 1, Math.floor(p * s.length))]; };
const col = (f) => manifest.map(m => f(m.metrics));
const line = (name, xs) => `| ${name} | ${q(xs,0)} | ${q(xs,.1)} | ${q(xs,.5)} | ${q(xs,.9)} | ${q(xs,1)} |`;

let rep = `# Synthetic Pureland corpus -- pilot batch\n\n`;
rep += `${manifest.length} samples, seed0 ${SEED0}, generated ${new Date().toISOString().slice(0,10)}.\n`;
rep += `coupling cap: ${COUPLING_CAP ?? "none"}   coupling frac: ${COUPLING_FRAC ?? "none"}   `;
rep += `reject filters: ${REJECT.length ? REJECT.join(",") : "none"}\n\n`;
rep += `> Read this before fixing any cut point. Both the coupling strata and the degeneracy\n`;
rep += `> filters are deliberately unset in this batch -- the numbers below are what they are\n`;
rep += `> supposed to be chosen from.\n\n## Distribution\n\n`;
rep += `| metric | min | p10 | p50 | p90 | max |\n| --- | --- | --- | --- | --- | --- |\n`;
rep += [
    line("steps", col(m => m.steps)),
    line("crease edges", col(m => m.crease_edges)),
    line("distinct crease lines", col(m => m.distinct_crease_lines)),
    line("**coupling max**", col(m => m.coupling_max)),
    line("**coupling mean**", col(m => m.coupling_mean)),
    line("coupling total", col(m => m.coupling_total)),
    line("layers final", col(m => m.layers_final)),
    line("vertices", col(m => m.vertices)),
    line("bbox area final", col(m => m.bbox_area_final)),
].join("\n");

rep += `\n\n## Per stratum\n\n| stratum | cap | n | steps p50 | coupling max p50 | crease edges p50 | degenerate |\n| --- | --- | --- | --- | --- | --- | --- |\n`;
for (const st of strata) {
    const g = manifest.filter(m => m.stratum === st.name);
    const cap = st.coupling_cap ?? COUPLING_CAP ?? (st.coupling_frac ?? COUPLING_FRAC ? `x${st.coupling_frac ?? COUPLING_FRAC}` : "none");
    if (!g.length) { rep += `| ${st.name} | ${cap} | 0 | - | - | - | - |\n`; continue; }
    rep += `| ${st.name} | ${cap} | ${g.length} | ${q(g.map(m=>m.metrics.steps),.5)} | ${q(g.map(m=>m.metrics.coupling_max),.5)} | ${q(g.map(m=>m.metrics.crease_edges),.5)} | ${g.filter(m=>m.metrics.degenerate).length} |\n`;
}

rep += `\n## Degeneracy flags (recorded, not filtered)\n\n| flag | n | share |\n| --- | --- | --- |\n`;
for (const f of ["repeated_halving", "no_coupling", "collapsed", "single_angle"]) {
    const n = manifest.filter(m => m.metrics.flags[f]).length;
    rep += `| ${f} | ${n} | ${manifest.length ? (100*n/manifest.length).toFixed(1) : 0}% |\n`;
}

rep += `\n## Rejected during sampling\n\n| reason | n |\n| --- | --- |\n`;
for (const [k, v] of Object.entries(rejects).sort((a,b)=>b[1]-a[1])) rep += `| ${k} | ${v} |\n`;


fs.writeFileSync(path.join(OUT, "report.md"), rep);
console.log(`\n${manifest.length} samples, ${Object.values(rejects).reduce((a,b)=>a+b,0)} rejected`);
console.log(`report  -> ${path.relative(process.cwd(), path.join(OUT, "report.md"))}`);
}
