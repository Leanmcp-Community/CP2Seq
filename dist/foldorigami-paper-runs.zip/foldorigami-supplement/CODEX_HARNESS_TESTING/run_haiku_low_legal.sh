#!/bin/sh
# Claude arm, claude-haiku-4-5, legal-fold enumeration condition.
# Every shared flag lives in _claude_common.sh so the model scripts cannot drift apart.
set -eu
MODEL=claude-haiku-4-5
. "$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)/_claude_common.sh"
